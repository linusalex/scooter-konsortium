﻿using MySqlConnector;

var builder = WebApplication.CreateBuilder(args);

var app = builder.Build();

string connectionString =
    "Server=localhost;Port=3306;Database=scooter_consortium;User ID=root;Password=;";

// =========================================================
// GET /
// =========================================================

app.MapGet("/", () =>
{
    return "ScooterAPI läuft!";
});


// =========================================================
// GET /api/scooters
// Alle Scooter
// =========================================================

app.MapGet("/api/scooters", async () =>
{
    var scooters = new List<object>();

    await using var connection = new MySqlConnection(connectionString);
    await connection.OpenAsync();

    const string sql = """
        SELECT
            scooter_id,
            company_id,
            user_id,
            charging_point_id,
            location_id,
            battery_level,
            revenue,
            distance_km,
            status
        FROM scooter
        ORDER BY scooter_id;
        """;

    await using var command = new MySqlCommand(sql, connection);
    await using var reader = await command.ExecuteReaderAsync();

    while (await reader.ReadAsync())
    {
        scooters.Add(new
        {
            scooterId = reader["scooter_id"],
            companyId = reader["company_id"],
            userId = reader["user_id"],
            chargingPointId = reader["charging_point_id"],
            locationId = reader["location_id"],
            batteryLevel = reader["battery_level"],
            revenue = reader["revenue"],
            distanceKm = reader["distance_km"],
            status = reader["status"]
        });
    }

    return Results.Ok(scooters);
});


// =========================================================
// GET /api/scooters/map
// Scooter-Daten für die Karte inklusive GPS
// =========================================================

app.MapGet("/api/scooters/map", async () =>
{
    var scooters = new List<object>();

    await using var connection = new MySqlConnection(connectionString);
    await connection.OpenAsync();

    const string sql = """
        SELECT
            s.scooter_id,
            s.company_id,
            c.name AS company_name,
            s.location_id,
            l.latitude,
            l.longitude,
            s.battery_level,
            s.status
        FROM scooter s
        INNER JOIN company c
            ON s.company_id = c.company_id
        INNER JOIN location l
            ON s.location_id = l.location_id
        ORDER BY s.scooter_id;
        """;

    await using var command = new MySqlCommand(sql, connection);
    await using var reader = await command.ExecuteReaderAsync();

    while (await reader.ReadAsync())
    {
        scooters.Add(new
        {
            scooterId = reader["scooter_id"],
            companyId = reader["company_id"],
            companyName = reader["company_name"],
            locationId = reader["location_id"],
            latitude = reader["latitude"],
            longitude = reader["longitude"],
            batteryLevel = reader["battery_level"],
            status = reader["status"]
        });
    }

    return Results.Ok(scooters);
});


// =========================================================
// GET /api/scooters/available
// Nur aktive Scooter
// =========================================================

app.MapGet("/api/scooters/available", async () =>
{
    var scooters = new List<object>();

    await using var connection = new MySqlConnection(connectionString);
    await connection.OpenAsync();

    const string sql = """
        SELECT
            s.scooter_id,
            c.name AS company_name,
            l.latitude,
            l.longitude,
            s.battery_level,
            s.status
        FROM scooter s
        INNER JOIN company c
            ON s.company_id = c.company_id
        INNER JOIN location l
            ON s.location_id = l.location_id
        WHERE s.status = 'active'
        ORDER BY s.scooter_id;
        """;

    await using var command = new MySqlCommand(sql, connection);
    await using var reader = await command.ExecuteReaderAsync();

    while (await reader.ReadAsync())
    {
        scooters.Add(new
        {
            scooterId = reader["scooter_id"],
            companyName = reader["company_name"],
            latitude = reader["latitude"],
            longitude = reader["longitude"],
            batteryLevel = reader["battery_level"],
            status = reader["status"]
        });
    }

    return Results.Ok(scooters);
});


// =========================================================
// GET /api/scooters/{id}
// Einzelnen Scooter anzeigen
// =========================================================

app.MapGet("/api/scooters/{id:int}", async (int id) =>
{
    await using var connection = new MySqlConnection(connectionString);
    await connection.OpenAsync();

    const string sql = """
        SELECT
            s.scooter_id,
            s.company_id,
            c.name AS company_name,
            s.user_id,
            s.charging_point_id,
            s.location_id,
            l.latitude,
            l.longitude,
            s.battery_level,
            s.revenue,
            s.distance_km,
            s.status
        FROM scooter s
        INNER JOIN company c
            ON s.company_id = c.company_id
        INNER JOIN location l
            ON s.location_id = l.location_id
        WHERE s.scooter_id = @id;
        """;

    await using var command = new MySqlCommand(sql, connection);
    command.Parameters.AddWithValue("@id", id);

    await using var reader = await command.ExecuteReaderAsync();

    if (!await reader.ReadAsync())
    {
        return Results.NotFound(new
        {
            message = $"Scooter mit ID {id} wurde nicht gefunden."
        });
    }

    var scooter = new
    {
        scooterId = reader["scooter_id"],
        companyId = reader["company_id"],
        companyName = reader["company_name"],
        userId = reader["user_id"],
        chargingPointId = reader["charging_point_id"],
        locationId = reader["location_id"],
        latitude = reader["latitude"],
        longitude = reader["longitude"],
        batteryLevel = reader["battery_level"],
        revenue = reader["revenue"],
        distanceKm = reader["distance_km"],
        status = reader["status"]
    };

    return Results.Ok(scooter);
});


// =========================================================
// GET /api/companies
// Alle Unternehmen
// =========================================================

app.MapGet("/api/companies", async () =>
{
    var companies = new List<object>();

    await using var connection = new MySqlConnection(connectionString);
    await connection.OpenAsync();

    const string sql = """
        SELECT
            company_id,
            name,
            cost_per_km,
            address,
            hotline
        FROM company
        ORDER BY name;
        """;

    await using var command = new MySqlCommand(sql, connection);
    await using var reader = await command.ExecuteReaderAsync();

    while (await reader.ReadAsync())
    {
        companies.Add(new
        {
            companyId = reader["company_id"],
            name = reader["name"],
            costPerKm = reader["cost_per_km"],
            address = reader["address"],
            hotline = reader["hotline"]
        });
    }

    return Results.Ok(companies);
});


// =========================================================
// GET /api/charging-points
// Alle Ladestationen
// =========================================================

app.MapGet("/api/charging-points", async () =>
{
    var chargingPoints = new List<object>();

    await using var connection = new MySqlConnection(connectionString);
    await connection.OpenAsync();

    const string sql = """
        SELECT
            charging_point_id,
            name,
            x,
            y,
            capacity,
            occupied
        FROM charging_point
        ORDER BY charging_point_id;
        """;

    await using var command = new MySqlCommand(sql, connection);
    await using var reader = await command.ExecuteReaderAsync();

    while (await reader.ReadAsync())
    {
        chargingPoints.Add(new
        {
            chargingPointId = reader["charging_point_id"],
            name = reader["name"],
            x = reader["x"],
            y = reader["y"],
            capacity = reader["capacity"],
            occupied = reader["occupied"]
        });
    }

    return Results.Ok(chargingPoints);
});


// =========================================================
// START SERVER
// =========================================================

app.Run();
